"""Hollow Boomer (HOBO)

Common use, non-production functionality used for testing, integration, etc.

Package Modules:

- argmanager: Facilities the user setting a list of arguments and/or argument/value pairs.
- common_automation: General automation helper functions.
- cosmicraygun: Defines functionality for corrupting files on-disk.
- daemon_automation: `systemctl` commands executed using `subprocess`.
- disk_operations: Manipulates and reports on files and directories.
- makefile_automation: `makefile` rules executed using `subprocess`.
- makefile_rule: Validates and executes a single Makefile rule using `subprocess`.
- makefile_rule_collection: Collects and validates common `MakefileRule` objects.
- memwatch_automation: Facilitates the execution of a Linux daemon using memwatch.
- misc: A catch-all module.
- network: Defines basic Internet Protocol (IP) based functionality.
- ssh_manager: Facilitates coping of files/folders and remote command execution via secured shell.
- subprocess_wrapper: Facilitate the use of `subprocess` by wrapping common idioms.
- valgrind_automation: Facilitates the execution of a Linux daemon using Valgrind.
- valgrindlogparser: Reads, parses, interprets, and reports on Valgrind log files.
- validation: Functions to facilitate the standardized validation of input.
- vm_manager: Facilitates virtual machine startup and shutdown using VMWare.
- xml: Functions to operate on XML-formatted files and strings.
- zipmanager: Defines functionality to validate, read, and expand ZIP files.

"""

# HOBO version
__version__ = '1.5.0'
