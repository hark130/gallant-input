"""Defines the ArgManager class.

Allows the user to set a list of arguments and/or set argument/value pairs.  Also allows the
user to query settings at any given time.  Finally, constructs a set of argument/value pairs
into a list of arguments for use with subprocess.

    Typical usage example:

    arg_mngr = ArgManager()
    arg_mngr.add_arg('--in', 'input.txt')  # Key/value argument
    arg_mngr.add_arg('-v', None)           # On/off flag
    cmd_list = arg_mngr.get_cmd_list()     # Returns: ['--in', 'input.txt', '-v']
"""


# Standard Imports
from collections import OrderedDict
# Local Imports
from hobo.validation import validate_list, validate_string, validate_type


def validate_cmd_list(cmd_list: list) -> None:
    """Validate a command list.

    Validates the cmd_list and its contents.

    Args:
        cmd_list: A list of non-empty strings to use as the command list.

    Raises:
        TypeError: A bad type was found.
        ValueError: An empty string was found in the command list.
    """
    # Command List
    validate_list(cmd_list, 'command list attribute', can_be_empty=True)
    for cmd_entry in cmd_list:
        validate_string(cmd_entry, 'command list entry', can_be_empty=False)


class ArgManager():
    """Dynamically manages subprocess-style command arguments.

    Object stores user input to facilitate dependency injection across multiple function calls.

    Standard use case: Add arguments, query arguments, and construct the command list.
    Standard usage example:
        arg_mngr = ArgManager()
        arg_mngr.add_arg('--in', 'input.txt')  # Key/value argument
        arg_mngr.add_arg('-v', None)           # On/off flag
        arg_mngr.get_arg_value('--in')         # Returns: 'input.txt'
        arg_mngr.get_arg_value('-v')           # Returns: None
        cmd_list = arg_mngr.get_cmd_list()     # Returns: ['--in', 'input.txt', '-v']
        # Command list will be created when needed and, by default, only be created once.
        # Additional calls to add_arg() will not modify the command list unless you clear the
        #   command list with a call to clear_cmd_list() or force a from-scratch rebuild with
        #   get_cmd_list(rebuild=True).

    Override use case: Set the command list.
    Override usage example:
        arg_mngr = ArgManager()
        arg_mngr.set_cmd_list(['--help'])      # Take care when using this functionality
        cmd_list = arg_mngr.get_cmd_list()     # Returns: ['--help']
    """

    def __init__(self) -> None:
        """ArgManager ctor."""
        self._arg_dict = OrderedDict()  # Store arg/value pairs
        self._cmd_list = []             # Subprocess-style command list

    # USER METHODS
    # Methods listed in "suggested" call order

    def add_arg(self, arg: str, value: str, overwrite: bool = True) -> None:
        """Add arg/value pair to command list.

        Set an argument and associated value to be added to the list of arguments.

        Args:
            arg: The argument to add to the command list.
            value: Associated value for arg.  This can be None or an empty string for on/off
                argument flags.  E.g., arg='-v', value=None will resolve to ['-v'] in the
                command list.  So will arg='-v', value=''.
            overwrite: Optional; If arg has already been set, this controls whether or not to
                modify arg's value.

        Raises:
            TypeError: arg is a non-string.
            ValueError: arg is empty.
            KeyError: arg already exists but overwrite is False.
        """
        # INPUT VALIDATION
        # arg
        validate_string(arg, 'arg', can_be_empty=False)
        # value
        if value is not None:
            validate_string(value, 'value', can_be_empty=True)
        # overwrite
        validate_type(overwrite, 'overwrite', bool)

        # STORE IT
        if arg in self._arg_dict:
            if not overwrite:
                raise KeyError(f'Argument {arg} already exists')
        self._arg_dict[arg] = value

    def get_arg_value(self, arg: str) -> str:
        """Get the value for arg from the command list.

        Returns the value associated with arg by checking the argument dictionary.
        WARNING: Calling set_cmd_list() and then get_arg_value() may not yield expected results.
            If you manually set the command list then it is recommended that you keep track of
            the argument values as well.

        Args:
            arg: The argument, represented as a non-empty string, you want the value for.

        Returns:
            Could be a string.  Could also be an empty string or None, depending on user input,
            indicating that argument was never given a value (e.g., -v).
        """
        # LOCAL VARIABLES
        arg_val = None  # Argument value to return

        # ATTRIBUTE VALIDATION
        self._validate_internals()

        # FIND IT
        if arg in self._arg_dict:
            arg_val = self._arg_dict[arg]

        # DONE
        return arg_val

    def get_cmd_list(self, rebuild: bool = False) -> list:
        """Get the command list.

        Validates the internal attributes, constructs the command list (if it hasn't already been
        done) and returns it.

        Args:
            rebuild: Optional; Build the command list from scratch.

        Returns:
            A list of strings built from the user's input.  The list will be empty if no
            arguments or command lists have been set.

        Raises:
            TypeError: A bad type was found.
            ValueError: An bad value was found.
        """
        # INPUT VALIDATION
        validate_type(rebuild, 'rebuild', bool)

        # GET IT
        if rebuild:
            self.clear_cmd_list()
        self._create_cmd_list()

        # DONE
        return self._cmd_list

    def clear_cmd_list(self) -> None:
        """Clear the command list.

        The command list is essentially locked once it gets built.  Call this method to unlock
        the command list so it can be modified.  Previously added arguments will remain.  If
        you want to clear *everything*, then call set_cmd_list([], overwrite=True) instead.
        """
        self._cmd_list.clear()  # Clear the command list so it can be modified

    def set_cmd_list(self, cmd_list: list, overwrite: bool = False) -> None:
        """Set the command list.

        Sets the command list with user input.

        Args:
            cmd_list: A list of non-empty strings to use as the command list.
            overwrite: Optional; If command list has already been constructed, this controls
                whether or not to replace an existing list.  If True, the existing list will be
                replaced and the argument dictionary will be emptied.

        Raises:
            TypeError: A bad type was found.
            ValueError: An bad value was found.
            RuntimeError: Command list already exists but overwrite is False.
        """
        # INPUT VALIDATION
        validate_cmd_list(cmd_list=cmd_list)
        validate_type(overwrite, 'overwrite', bool)

        # SET IT
        if self._cmd_list:
            if not overwrite:
                raise RuntimeError('Command list already exists.  Call clear_cmd_list() to reset.')
        self._cmd_list = cmd_list

        # CLEAR ARG DICT
        self._arg_dict = OrderedDict()

    # CLASS HELPER METHODS
    # Methods listed in alphabetical order
    def _create_cmd_list(self) -> None:
        """Creates the command list if it does not already exist.

        Validates the internal attributes.  Then creates the command list using the argument
        dictionary entries but only if the command list doesn't already exists
        (e.g., self.set_cmd_list() or  self._create_cmd_list() were already called).

        Raises:
            TypeError: A bad type was found.
            ValueError: An bad value was found.
        """
        # ATTRIBUTE VALIDATION
        self._validate_internals()

        # CREATE IT
        if not self._cmd_list:
            for key, value in self._arg_dict.items():
                self._cmd_list.append(key)
                if value:
                    self._cmd_list.append(value)

    def _validate_arg_dict(self) -> None:
        """Validate the argument dictionary class attribute.

        Validates the self._arg_dict attribute and its contents.

        Raises:
            TypeError: A bad type was found.
            ValueError: An empty argument string was found.
        """
        # Argument Dictionary
        validate_type(self._arg_dict, 'argument dictionary attribute', OrderedDict)
        for key, value in self._arg_dict.items():
            validate_string(key, 'argument dictionary key', can_be_empty=False)
            if value is not None:
                validate_string(value, 'argument dictionary value', can_be_empty=True)

    def _validate_internals(self) -> None:
        """Validate the class attributes.

        Raises:
            TypeError: A bad type was found.
            ValueError: An bad value was found.
        """
        # Argument Dictionary
        self._validate_arg_dict()
        # Command List
        validate_cmd_list(self._cmd_list)
