"""Defines the CosmicRayGun class.

The CosmicRayGun class allows the caller to easily 'corrupt' a file.

    Typical usage example:

    my_file = Path('my_file.txt')  # Original file
    crg = CosmicRayGun(my_file)    # Cosmic ray gun is loaded
    crg.flip_random_bit()          # Cosmic ray gun fired and my_file will never be the same

FUN FACT: Cosmic rays are atom fragments that rain down on the Earth from outside of the solar
    system. They blaze at the speed of light and have been blamed for electronics problems in
    satellites and other machinery.  (source: https://www.space.com/32644-cosmic-rays.html)
"""

# Standard Imports
from copy import deepcopy
from math import floor
from pathlib import Path
import random  # This import style is key to mock the randint() function call in the unit tests
# Local Imports
from hobo.disk_operations import validate_file
from hobo.validation import validate_type


class CosmicRayGun:
    """Corrupt a file.

    Allows a caller to corrupt a file on-disk.
    """

    def __init__(self, target: Path) -> None:
        """CosmicRayGun class constructor.

        Args:
            target: Path object to a file that exists.
        """
        # ATTRIBUTES
        self._target = target  # Shoot the Cosmic Ray Gun at this file

    def flip_random_bit(self) -> None:
        """Flips a random bit in target.

        Reads target's contents, randomizes a bit, toggles it, and writes the results to target.

        Raises:
            TypeError: Bad data type.
            FileNotFoundError: target is unavailable.
            OSError: target is not a file.
            IndexError: randomized bit is out of scope.
        """
        # LOCAL VARIABLES
        old_data = None  # Data read from target as a bytearray
        new_data = None  # old_data with a bit flipped as a bytearray

        # INPUT VALIDATION
        self._validate_ctor_input()

        # DO IT
        # Read contents
        old_data = bytearray(self._target.read_bytes())
        # Flip a bit
        new_data = _flip_bit(data=old_data, bit_index=random.randint(0, (len(old_data) * 8) - 1))
        # Write new data
        self._target.write_bytes(new_data)

    def get_target(self) -> Path:
        """Get the RayGun's target.

        Returns:
            The target, which may or may not be valid, as defined in the constructor.
        """
        return self._target

    def _validate_ctor_input(self) -> None:
        """Validate ctor input.

        Raises:
            TypeError: Bad data type.
            FileNotFoundError: target is unavailable.
            OSError: target is not a file.
        """
        _validate_path_file(path_file=self._target)


def _flip_bit(data: bytearray, bit_index: int) -> bytearray:
    """Flip bit number bit_index in data.

    Toggle bit number bit_index within data.

    Args:
        data: Bytearray of data to modify by flipping a bit.
        bit_index: Bit index to flip.  Available choices for data of length greater than zero
            are 0 through data length minus 1: 0 <--> len(data) * 8 - 1.

    Returns:
        A deepcopy of data with bit position bit_index flipped.

    Raises:
        TypeError: Invalid data type.
        ValueError: Empty bytearray.
        IndexError: bit_index is out of scope.
    """
    # LOCAL VARIABLES
    flipped_data = None  # Deep copy of data that's been modified
    bit_len = 0          # Number of bits in data
    byte_index = 0       # Data index to modify
    bit_mask = 0         # Data mask to flip bit_index within byte_index

    # VALIDATION
    # Input
    validate_type(data, 'data', bytearray)
    if not data:
        raise ValueError('data can not be empty')
    validate_type(bit_index, 'bit_index', int)
    # Context
    flipped_data = deepcopy(data)
    bit_len = len(flipped_data) * 8
    if bit_index < 0:
        raise IndexError(f'Bit index {bit_index} is invalid')
    if bit_index >= bit_len:
        raise IndexError(f'Data has {bit_len - 1} indices so {bit_index} is out of bounds')

    # FLIP IT
    byte_index = floor(bit_index / 8)
    bit_mask = 1 << (7 - (bit_index % 8))
    flipped_data[byte_index] = flipped_data[byte_index] ^ bit_mask

    # DONE
    return flipped_data


def _validate_path_file(path_file: Path) -> None:
    """Validate a Path object as a file.

    Args:
        path_file: Path object to validate as a file.

    Raises:
        TypeError: Bad data type.
        FileNotFoundError: path_file is unavailable.
        OSError: path_file is not a file.
    """
    # INPUT VALIDATION
    validate_type(var=path_file, var_name='path_file', var_type=Path)
    validate_file(filename=str(path_file.absolute()), param_name='path_file', must_exist=True)
