"""Common operations on files and directories.

This module contains functionality that, but is not limited to: adding, counting, deleting, and
listing files and directories.

    Typical usage example:

    from hobo.disk_operations import (count_dirs_in_path, create_dir, create_file, delete_file,
                                      delete_files, destroy_dir, find_path_to_dir, list_files,
                                      read_file, remove_dir, validate_directory, validate_file)

    dir_count = count_dirs_in_path('hollow-boomer/src/hobo', ignore_missing)
    create_dir('hobo/new-directory', ignore_missing)
    create_file('HelloWorld.txt', 'Hello World.')
    delete_file(abs_log_filename, ignore_missing=True)
    delete_files(dirname)
    destroy_dir('build')
    path_to_dir = find_path_to_dir(dir_to_find='hollow-boomer')
    file_list = list_files(dirname)
    contents = read_file(repo_dir, 'README.md')
    remove_dir(dirname, ignore_missing)
    validate_directory(repo_path, 'repo_path')
    validate_file(self._makefile_filename, 'makefile_filename')
"""

# Standard Imports
import os
import hashlib
import re
from pathlib import Path
# Third Party Imports
# Local Imports
# pylint: disable=import-error
from hobo.validation import validate_list, validate_string, validate_type
# pylint: enable=import-error

# A list of reserved filename characters for the Windows OS
# From: https://docs.microsoft.com/en-us/windows/win32/fileio/naming-a-file
RESERVED_FNAME_CHARS_WIN = ['<', '>', ':', '"', '/', '\\', '|', '?', '*']

# A list of reserved (and more) filename characters for Linux
# From: https://www.cyberciti.biz/faq/\
#   linuxunix-rules-for-naming-file-and-directory-names/
RESERVED_FNAME_CHARS_LIN = ['/', '>', '<', '|', ':', '&', '\\', '(', ')', ';', '?', '*']

MB = 1048576  # Exact size of 1 Megabyte


def append_file(file_path: str, text: str, must_exist: bool = True,
                encoding: str = 'utf-8') -> None:
    """Appends text to the end of a file.

    Validates file and appends text.

    Args:
        file_path: Path of the file to append to.
        text: Text string to append.
        must_exist: Optional; if True, verifies file exists.
        encoding: Optional; Encoding of file to be read.

    Raises:
        FileNotFoundError: must_exist is True but file_path is not found.
        OSError: must_exist is True but file_path is not a file.
        TypeError: Invalid data type.
        ValueError: Empty string.
    """
    # Validate types
    validate_type(file_path, 'file_path', str)
    validate_string(text, 'text')
    validate_string(encoding, 'encoding')
    validate_type(must_exist, 'must_exist', bool)

    # Validate file exists
    validate_file(file_path, 'file_path', must_exist)

    # Append text to file
    with open(file_path, 'a', encoding=encoding) as file:
        file.write(text)


def calc_file_md5sum(filepath: Path) -> str:
    """Calculate the MD5 message digest of a file.

    Reads the provided file, calculating and returning the
    md5sum of the contents.

    Reads in 100MB of the provided file at a time, updating the
    hash as it goes. This will enable the function to handle
    arbitrarily large files.

    Args:
        filepath: The path to the file

    Returns:
        A string containing the md5sum of the file contents.

    Raises:
        FileNotFoundError: file is not found
        TypeError: filepath is not a Path
        IsADirectoryError: filepath is a directory
    """
    # Input Validation
    if not isinstance(filepath, Path):
        raise TypeError(f'Expected Path object, not {type(filepath)}.')

    if filepath.is_dir():
        raise IsADirectoryError(f'{filepath.name} is a directory, not a file.')

    if not filepath.exists():
        raise FileNotFoundError('Unable to hash file as it does not exist.')

    # MD5 calculation
    hashval = hashlib.md5()
    with open(filepath, 'rb') as file:
        chunk_size = 100 * MB
        while True:
            data = file.read(chunk_size)
            if not data:  # no data left to read, done
                break
            hashval.update(data)

    return hashval.hexdigest()


def count_dirs_in_path(dirname: str, ignore_missing: bool = False) -> int:
    """Counts the number of directories in dirname.

    The root directory will count as 1. Removes any trailing slashes in dirname to prevent a
    false count. For example: /tmp returns 2 while /tmp/ returns 3.

    Args:
        dirname: The relative or absolute pathname of the directory to count.
        ignore_missing: Optional; If True, missing names will count as 0.

    Returns:
        An integer representing the number of directories in dirname.

    Raises:
        FileNotFoundError: ignore_missing is False and any of dirname missing.
        TypeError: Invalid data type.
        ValueError: dirname is empty.
    """
    existing_dir = dirname  # The portion of dirname that actually exists
    dir_count = 0           # Running count of directories

    # INPUT VALIDATION
    # ignore_missing
    validate_type(ignore_missing, 'ignore_missing', bool)
    # dirname
    try:
        validate_directory(dirname, 'dirname', not ignore_missing)
    except FileNotFoundError as err:
        if ignore_missing:
            existing_dir = _find_existing_parent_dir(dirname)
        else:
            raise err

    # SANITIZE
    while (len(existing_dir) > 1
           and existing_dir[len(existing_dir) - 1:] == '/'):
        existing_dir = existing_dir[:len(existing_dir) - 1]

    # COUNT
    dir_count = _count_dirs_in_path(existing_dir)

    # DONE
    return dir_count


def create_dir(dirname: str, ignore_existing: bool = True) -> None:
    """Recursively creates directory named dirname.

    Creates directory and any intermediate directories. Any path segments that do not exist will
    be created. All directories are created with default permissions of mode = o777. Some systems
    will ignore this value. Windows will create a directory with permissions for the current user
    and any administrators.

    Args:
        dirname: The relative or absolute pathname of the directory to create.
        ignore_existing: Optional; If True, silences exceptions if the directory already exists.

    Raises:
        FileExistsError: ignore_existing is False and dirname already exists.
        TypeError: Invalid data type.
        ValueError: dirname is empty.
    """
    # INPUT VALIDATION
    # dirname
    validate_string(dirname, 'dirname')
    # ignore_existing
    validate_type(ignore_existing, 'ignore_existing', bool)

    os.makedirs(dirname, exist_ok=ignore_existing)


def create_file(filename: str, contents: str = '', ignore_existing: bool = False) -> None:
    """Creates a file with provided contents.

    Creates a file named filename and writes contents to that file.

    Args:
        filename: The relative or absolute pathname of the file to create.
        contents: Optional; The contents to add to that file.
        ignore_existing: Optional; If True, and filename exists, overwrite it.

    Raises:
        FileExistsError: ignore_existing is False and filename already exists.
        TypeError: Invalid data type.
        ValueError: filename is empty.
    """
    # INPUT VALIDATOIN
    # filename
    validate_string(filename, 'filename')
    # contents
    validate_string(contents, 'contents', can_be_empty=True)
    # ignore_existing
    validate_type(ignore_existing, 'ignore_existing', bool)

    # ENVIRONMENT VALIDATION
    if not ignore_existing:
        if os.path.exists(filename):
            raise FileExistsError(f'"{filename}" already exists')

    # CREATE AND WRITE
    with open(filename, 'w', encoding='utf-8') as out_file:
        out_file.write(contents)


def delete_file(filename: str, ignore_missing: bool = False) -> None:
    """Deletes a file.

    Validates input and deletes filename.

    Args:
        filename: The relative or absolute pathname of the file to delete.
        ignore_missing: Optional; If True, silences exceptions if the file can't be found.

    Raises:
        FileNotFoundError: filename is missing and ignore_missing is False.
        OSError: filename is not a file.
        TypeError: Invalid data type.
        ValueError: filename is empty.
    """
    # INPUT VALIDATION
    # ignore_missing
    validate_type(ignore_missing, 'ignore_missing', bool)
    # filename
    validate_string(filename, 'filename')

    # DELETE FILE
    try:
        os.remove(filename)
    except FileNotFoundError as err:
        if not ignore_missing:
            raise err


def delete_files(dirname: str, exempt: list = None) -> None:
    """Deletes all files found in a directory.

    Deletes all files found in dirname. The function will not travel within any
    sub-directories and considers empty directories as a "success".

    Args:
        dirname: The relative or absolute pathname of the directory to empty.
        exempt: Optional; A list of filenames, as strings, to avoid deleting.

    Raises:
        OSError: dirname does not exist or dirname is not a directory.
        TypeError: Invalid data type.
        ValueError: dirname is empty.
    """
    # INPUT VALIDATION
    # dirname
    validate_directory(dirname, 'dirname')
    # exempt
    if exempt is not None:
        validate_list(exempt, 'exempt', can_be_empty=True)

    # LOCAL VARIABLES
    # Local copy of exempt
    if exempt:
        local_exempt = exempt
    else:
        local_exempt = []
    # Files found in dirname
    files_to_delete = [os.path.join(dirname, file)
                       for file in os.listdir(dirname)
                       if os.path.isfile(os.path.join(dirname, file))
                       and file not in local_exempt]

    # DELETE FILES
    for file in files_to_delete:
        delete_file(file)


def destroy_dir(dirname: str) -> None:
    """Deletes all files and sub-directories in a directory, then removes the directory.

    Before removing dirname, the function recursively deletes all files and sub-directories.
    Sub-directories are not explicitly entered and empty directories are considered as a "success".

    Args:
        dirname: The relative or absolute pathname of the directory to destroy.

    Raises:
        OSError: dirname does not exist or dirname is not a directory.
        TypeError: Invalid data type.
        ValueError: dirname is empty.
    """
    dir_list = []  # List of directories found in dirname

    # INPUT VALIDATION
    validate_directory(dirname, 'dirname')

    # DESTROY
    # Destroy subordinate folders
    dir_list = [file for file in os.listdir(dirname) if
                os.path.isdir(os.path.join(dirname, file))]
    for subdir in dir_list:
        destroy_dir(os.path.join(dirname, subdir))
    # Destroy files
    delete_files(dirname)
    # Destory dirname
    remove_dir(dirname, ignore_missing=False)


def find_path_to_dir(dir_to_find: str, cur_dir: str = os.getcwd()) -> str:
    """Finds the path to a directory that is within another directory.

    Finds path to dir_to_find within cur_dir.

    Args:
        dir_to_find: The 'needle'; The directory to find path of.
        cur_dir: Optional; The 'haystack'; The path of one or more directories.

    Returns:
        A string containing the path of cur_dir up to dir_to_find.

    Raises:
        OSError: dir_to_find not found in cur_dir.
        TypeError: Invalid data type.
        ValueError: Empty string.
    """
    # LOCAL VARIABLES
    path_to_dir = ''  # Return value
    temp_head = ''    # Temp "head" path from split()
    temp_tail = ''    # Temp "tail" directory from split()

    # INPUT VALIDATION
    # dir_to_find
    validate_string(dir_to_find, 'dir_to_find')
    # cur_dir
    validate_string(cur_dir, 'cur_dir')
    # dir_to_find in cur_dir
    if dir_to_find not in cur_dir:
        raise OSError(f'Unable to find {dir_to_find} in {cur_dir}')

    # FIND IT
    temp_head = cur_dir
    while True:
        if temp_tail == dir_to_find:
            path_to_dir = os.path.join(temp_head, temp_tail)
            break
        (temp_head, temp_tail) = os.path.split(temp_head)

        if not temp_head and not temp_tail:
            raise OSError(f'Unable to find {dir_to_find} in {cur_dir}')

    # DONE
    return path_to_dir


def list_files(dirname: str, include_dirname: bool = False) -> list:
    """Returns a list of file names found in a directory.

    Returns a list of file names found in dirname. If there are no files found in dirname, the list
    will be empty.

    Args:
        dirname: The relative or absolute pathname of the directory to search.
        include_dirname: Optional; If True, includes the directory name with each file name in the
            returned list.

   Raises:
        FileNotFoundError: dirname is missing.
        OSError: dirname is not a directory.
        TypeError: Invalid data type.
        ValueError: dirname is empty.
    """
    # LOCAL VARIABLES
    file_list = []  # List of files found in dirname

    # INPUT VALIDATION
    validate_directory(dirname, 'dirname')
    validate_type(include_dirname, 'include_dirname', bool)

    # LIST FILES
    file_list = [f for f in os.listdir(dirname)
                 if os.path.isfile(os.path.join(dirname, f))]
    if include_dirname:
        file_list = [os.path.join(dirname, f) for f in file_list]

    # DONE
    return file_list


# pylint: disable=too-many-locals
def modify_file(file_path: Path, regex: str, replace_str: str, must_find_match: bool = True,
                encoding: str = 'utf-8') -> None:
    """Replaces all matching text in a file based on regex pattern.

    Validates file, regex pattern and replaces specified text with replace string.

    Args:
        file_path: Path of the file to modify.
        regex: Regex pattern to apply to the file text.
        replace_str: Text string to replace the regex matches.
        must_find_match: Optional; True raises error if no matches were found; False raises
            error on matches found.
        encoding: Optional; Encoding of file to be read; defaults to UTF-8.

    Raises:
        FileNotFoundError: must_exist is True but file_path is not found.
        OSError: file_path is not a file.
        re.error: Invalid regex syntax.
        TypeError: Invalid data type.
        ValueError: No regex matches found in file_path contents.
        ValueError: file_path, regex or replace_str is empty.
    """
    # Validate types for non-strings
    validate_type(file_path, 'file_path', Path)
    validate_type(must_find_match, 'must_find_match', bool)

    # Validate strings
    validate_string(regex, 'regex')
    # Allow replace_str to be an empty str
    validate_string(replace_str, 'replace_str', can_be_empty=True)
    validate_string(encoding, 'encoding')

    # Validate regex
    try:
        pattern = re.compile(regex)
    except re.error as e:
        raise re.error(f'Supplied pattern is not valid regex: {regex}') from e

    # Validate file exists - not using validate_file() due to using Path instead of str
    if not file_path.exists():
        raise FileNotFoundError(f'Unable to find "{file_path.absolute().as_uri()}"')

    if not file_path.is_file():
        raise OSError(f'"{file_path.absolute().as_uri()}", param name file_path, is not a file')

    # Try reading the file
    try:
        with file_path.open('r', encoding=encoding) as file:
            file_contents = file.read()
    except PermissionError as e:
        message = f'Insufficient read permisions for {file_path.absolute().as_uri()}'
        raise PermissionError(message) from e

    # Find matches in file
    matches = re.findall(pattern, file_contents)

    # Validate search results
    if len(matches) > 0:
        # Raise error if there should be no matches
        if not must_find_match:
            raise ValueError(f'{len(matches)} matches were found but expected 0.')
        # Replace strings
        modified_contents = re.sub(pattern, replace_str, file_contents)
        # Try to overwrite the file with modified contents
        try:
            with file_path.open('w', encoding=encoding) as file:
                file.write(modified_contents)
        except PermissionError as e:
            message = f'Insufficient write permisions for {file_path.absolute().as_uri()}'
            raise PermissionError(message) from e
    elif must_find_match:
        # Raise error if matches expected but none found
        raise ValueError('Expected 1 or more matches but 0 were found.')
# pylint: enable=too-many-locals


def read_file(dirname: str, filename: str, must_exist: bool = True, encoding: str = 'utf-8') -> str:
    """Reads file from a directory.

    Reads filename from dirname and returns the contents as a string. If must_exist is False and
    the file does not exist, the function returns an empty string.

    Args:
        dirname: The directory to read filename from.
        filename: The name of the file to read.
        must_exist: Optional; If True, verifies filename exists.
        encoding: Optional; Name of the encoding used to decode the file.

    Returns:
        A string containing the contents of filename.

    Raises:
        FileNotFoundError: must_exist is True but dirname or filename is not found.
        LookupError: Encoding codec not found.
        OSError: must_exist is True and dirname is not a directory.
        OSError: must_exist is True and filename is not a file in dirname.
        TypeError: Invalid data type.
        ValueError: Empty string.
    """
    # LOCAL VARIABLES
    abs_filename = ''   # Combination of dirname and filename
    filename_cont = ''  # Contents of abs_filename

    # INPUT VALIDATION
    # dirname
    validate_directory(dirname, 'dirname', must_exist=must_exist)
    # filename
    validate_string(filename, 'filename')
    # abs_filename
    abs_filename = os.path.join(dirname, filename)
    validate_file(abs_filename, 'filename', must_exist=must_exist)

    # READ FILE
    with open(abs_filename, 'r', encoding=encoding) as in_file:
        filename_cont = in_file.read()

    # DONE
    return filename_cont


def remove_dir(dirname: str, ignore_missing: bool = True) -> None:
    """Removes a directory.

    Validates input and removes dirname.

    Args:
        dirname: The relative or absolute pathname of the directory to remove.
        ignore_missing: Optional; If True, silences exceptions if dirname is missing.

    Raises:
        FileNotFoundError: ignore_missing is False and dirname is missing.
        OSError: dirname is not an empty directory.
        TypeError: Invalid data type.
        ValueError: dirname is empty.
    """
    # INPUT VALIDATION
    # dirname
    validate_string(dirname, 'dirname')
    # ignore_missing
    validate_type(ignore_missing, 'ignore_missing', bool)

    # REMOVE DIR
    try:
        os.rmdir(dirname)
    except FileNotFoundError as err:
        if not ignore_missing:
            raise err


def validate_directory(validate_dir: str, param_name: str, must_exist: bool = True) -> None:
    """Standardizes how this module validates directory names.

    Validates all input, verifies validate_dir exists, and then verifies validate_dir is a
    directory.

    Args:
        validate_dir: The directory name to validate.
        param_name: The name of the parameter to be used in exception messages.
        must_exist: Optional; If True, verifies validate_dir exists.

    Raises:
        FileNotFoundError: must_exist is True but validate_dir is not found.
        TypeError: Invalid data type.
        ValueError: validate_dir or param_name is empty.
    """
    # INPUT VALIDATION
    validate_string(param_name, 'param_name')
    validate_string(validate_dir, param_name)
    validate_type(must_exist, 'must_exist', bool)

    # VALIDATION
    # Does it exist?
    if must_exist:
        _verify_existence(validate_dir)
    # Is it a directory?
    try:
        _verify_directory(validate_dir, param_name)
    except OSError as err:
        if must_exist:
            # Translate the OSError to a FileNotFoundError to match the docstring
            raise FileNotFoundError(str(err)) from err  # Should have been caught above


def validate_file(filename: str, param_name: str, must_exist: bool = True) -> None:
    """Standardizes how this module validates file names.

    Validates all input, verifies filename exists, and then verifies filename is a file.

    Args:
        filename: The relative or absolute pathname of the file to validate.
        param_name: The name of the parameter to be used in exception messages.
        must_exist: Optional; If True, verifies filename exists.

    Raises:
        FileNotFoundError: must_exist is True but filename is not found.
        OSError: must_exist is True but filename is not a file.
        TypeError: Invalid data type.
        ValueError: filename or param_name is empty.
    """
    # INPUT VALIDATION
    validate_string(param_name, 'param_name')
    validate_string(filename, param_name)
    validate_type(must_exist, 'must_exist', bool)

    # VALIDATION
    # Does it exist?
    if must_exist:
        _verify_existence(filename)
    # Is it a file?
    try:
        _verify_file(filename, param_name)
    except OSError as err:
        if must_exist:
            raise err  # Should have been caught above


#############################
# INTERNAL HELPER FUNCTIONS #
#############################


def _count_dirs_in_path(dirname: str) -> int:
    """Counts the number of directories in a directory.

    Counts the number of directories in dirname by recursively calling split. '/' always counts
    as 1. This function does not validate its input or verifies that dirname exists.

    Args:
        dirname: The relative or absolute pathname of the directory to count.

    Returns:
        An integer representing the number of directories in dirname.
    """
    # LOCAL VARIABLES
    count = 0                          # Current directory count from dirname
    split = os.path.split(dirname)[0]  # The head of dirname

    # COUNT
    if os.path.isdir(dirname):
        count += 1
    if split and dirname != split:
        count += _count_dirs_in_path(split)

    # DONE
    return count


def _find_existing_parent_dir(dirname: str) -> str:
    """Finds the parent directory of a directory.

    Finds the parent directory from dirname that exists. If dirname exists, the function returns
    dirname. If there is no parent directory that exists, an empty string is returned.

    Args:
        dirname: The relative or absolute pathname of the directory.

    Returns:
        A string containing the lowest-level directory from dirname or an empty string.

    Raises:
        TypeError: dirname is an invalid data type.
        ValueError: dirname is empty.
    """
    # LOCAL VARIABLES
    return_dir = dirname  # Return the existing parent directory

    # INPUT VALIDATION
    validate_string(dirname, 'dirname')

    # CHECK IT
    # Check the parameter value first
    if not os.path.isdir(return_dir):
        # Split it
        return_dir = os.path.split(return_dir)[0]
        if return_dir == dirname:
            return_dir = ''
        elif return_dir:
            return_dir = _find_existing_parent_dir(return_dir)

    # DONE
    return return_dir


def _verify_directory(verify_dir: str, param_name: str) -> None:
    """Standardizes how this module verifies something is a directory.

    Verifies verify_dir is a directory. This function does not validate input.

    Args:
        verify_dir: The name to validate is a directory.
        param_name: The name of parameter to be used in exception messages.

    Raises:
        OSError: verify_dir is not a directory.
    """
    # LOCAL VARIABLES
    not_dir = '"{}" is not a directory'

    # VALIDATION
    if not os.path.isdir(verify_dir):
        raise OSError(not_dir.format(param_name))


def _verify_existence(verify_exists: str) -> None:
    """Standardizes how this module validates directory names.

    Verifies verify_exists is a directory name. This function does not validate input.

    Args:
        verify_exists: The directory name to validate.

    Raises:
        FileNotFoundError: verify_exists does not exist.
    """
    # LOCAL VARIABLES
    missing = 'Unable to find "{}"'  # Template exception msg

    # FIND IT
    if not os.path.exists(verify_exists):
        raise FileNotFoundError(missing.format(verify_exists))


def _verify_file(verify_file: str, param_name: str) -> None:
    """Standardizes how this module verifies something is a file.

    Verifies verify_file is a file. This function does not validate input.

    Args:
        verify_file: The name to validate is a file.
        param_name: The name of the parameter to be used in exception messages.

    Raises:
        OSError: verify_file is not a file.
    """
    # LOCAL VARIABLES
    not_file = '"{}", param name {}, is not a file'

    # VALIDATION
    if not os.path.isfile(verify_file):
        raise OSError(not_file.format(verify_file, param_name))
