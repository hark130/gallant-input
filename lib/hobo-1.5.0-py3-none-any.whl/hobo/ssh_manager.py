"""Defines the SSHManager class.

Defines the SSHManager class to copy files/folders and execute commands via secured shell.

    Typical usage example:

    from hobo.ssh_manager import SSHManager

    IP_ADDRESS = '192.168.1.1'
    USERNAME = 'bob'
    PASSWORD = 'password'
    ssh_manager = SSHManager(IP_ADDRESS, USERNAME, PASSWORD)

    COMMAND = 'ls -la'
    try:
        ssh_manager.execute_command(COMMAND, timeout=10)
    except SSHTimeoutExpired as err:
        print('{err.args[0]}\nSTDOUT: {err.std_out}\nSTDERR: {err.std_err}\nEXIT: {err.exit_code}')
        # All of the above is also present in repr(err)

    LOCAL_PATH = 'C:\\Temp\\test_dir'
    LOCAL_FILE = 'C:\\Temp\\test_dir\\test.txt'
    REMOTE_PATH = '/tmp/test_dir'
    REMOTE_FILE = '/tmp/test_dir/test.txt'
    ssh_manager.create_remote_dir(REMOTE_PATH)
    ssh_manager.transfer_file_to_remote(LOCAL_PATH, REMOTE_PATH)
    ssh_manager.transfer_dir_to_remote(LOCAL_PATH, REMOTE_PATH)
    ssh_manager.transfer_file_to_local(REMOTE_FILE, LOCAL_PATH)
    ssh_manager.transfer_dir_to_local(REMOTE_PATH, LOCAL_PATH)

    ssh_manager.close()
"""

# Standard Imports
from pathlib import PurePosixPath, PureWindowsPath
from typing import List, Tuple
import os
import select
import shutil
import time
# Third Party Imports
from paramiko import SSHClient, SSHException, SFTPClient, AutoAddPolicy
# Local Imports
from hobo.disk_operations import validate_directory, validate_file
from hobo.validation import validate_list, validate_string


class SSHManagerError(Exception):
    """Custom exception for SSHManager errors and failures."""


class SSHTimeoutExpired(TimeoutError):
    """Custom exception for SSH Timeout errors and failures.

    Attributes:
        std_out: Optional; The stdout prior to the timeout expiration.
        std_err: Optional; The stderr prior to the timeout expiration.
        exit_code: Optional; The exit_code from the expired command.
    """

    def __init__(self, message: str = None, std_out: bytes = None,
                 std_err: bytes = None, exit_code: int = None):
        """SSHTimeoutExpired ctor.

        Args:
            message: Optional; The message detailing the error.
        """
        super().__init__(message)
        self.std_out = std_out
        self.std_err = std_err
        self.exit_code = exit_code

    def __repr__(self):
        """Returns representation of the object."""
        return (f'{self.__class__.__name__}(message={self.args[0]!r}, ' +
                f'std_out={self.std_out!r}, std_err={self.std_err!r}, ' +
                f'exit_code={self.exit_code!r})')


class SSHManager:
    """Secure Shell Manager Class.

    Defines functionality for managing an SSH connection to a remote host,
        particularly executing commands and issuing file transfers.

    Available features:
        1. Open an SSH connection to a remote host
        2. Execute arbitrary commands on the remote host
        3. Create directories on the remote host
        4. Transfer files from the local host to the remote host
        5. Transfer directories from the local host to the remote host
        6. Transfer files from the remote host to the local host
        7. Transfer directories from the remote host to the local host
        8. Close the SSH connection

    Attributes:
        client: Paramiko SSHClient object used for connections
    """

    # CONSTRUCTOR
    def __init__(self, host: str, username: str, password: str) -> None:
        """SSHManager ctor.

        Args:
            host: IP address of the host to SSH into.
            username: Account username to login with.
            password: Account password to login with.
        """
        self.client = SSHClient()
        self._host = host          # IP address of the host to SSH into
        self._username = username  # Account username to login with
        self._password = password  # Account password to login with
        self._connected = False    # Track the status of the connection
        self._os_type = ''         # 'Unix' or 'Windows'

    # DESTRUCTOR
    def __del__(self) -> None:
        """SSHManager dtor."""
        try:
            self.close()
        except (RuntimeError, SSHException):
            pass  # Silently fail...

    # PUBLIC FUNCTIONS
    def close(self) -> None:
        """Close the SSH connection.

        Raises:
            RuntimeError: The SSHClient object is missing.
            SSHManagerError: Problem closing SSH connection or connection timeout.
        """
        if not self.client:
            raise RuntimeError('The SSHClient object is missing')  # This should never happen
        if self._connected:
            try:
                self.client.close()
            except (SSHException, TimeoutError) as err:
                raise SSHManagerError(f'Problem closing SSH connection: {err}.') from err
            finally:
                self._connected = False

    def connect(self) -> None:
        """Establish the SSH connection.

        Raises:
            RuntimeError: The SSHClient object is missing.
            SSHManagerError: Problem opening SSH connection or connection timeout.
        """
        if not self.client:
            raise RuntimeError('The SSHClient object is missing')  # This should never happen
        if not self._connected:
            try:
                self.client.set_missing_host_key_policy(AutoAddPolicy())
                self.client.connect(self._host, username=self._username, password=self._password,
                                    timeout=10)
                self._connected = True
            except (SSHException, TimeoutError) as err:
                raise SSHManagerError(f'Problem opening SSH connection: {err}.') from err

    # pylint: disable=too-many-locals
    def execute_command(self, command: str, user_input: str = None,
                        timeout: int = None) -> Tuple[bytes, bytes, int]:
        """Execute a command on the remote host.

        Args:
            command: Command to execute on the remote host.
            user_input: Optional; The SSHClient will pass a non-empty string as stdin.
            timeout: Optional; Maximum number of seconds to wait command execution to complete.

        Returns:
            A tuple containing the contents of std_out and std_err in byte format as well as
            the exit code returned from the execution command.

        Raises:
            SSHManagerError: Unexpected problem with the connection or connection timeout.
            SSHTimeoutExpired: Timeout for command execution reached.
        """
        # LOCAL VARIABLES
        std_out = b''             # Store the standard out result
        std_err = b''             # Store the standard error result
        std_out_chunks = []       # Store the stdout chunks to be combined
        std_err_chunks = []       # Store the stderr chunks to be combined
        start_time = time.time()  # Starting time used when calculating timeout
        timeout_expired = False   # Flag indicating if timeout expired
        channel = None            # The SSH channel used in command execution
        exit_code = None          # The exit code returned from the command execution

        # SETUP
        self.connect()

        # EXECUTE IT
        if self._connected:
            try:
                in_channel, out_channel, _ = self.client.exec_command(command)
                channel = out_channel.channel  # Get the channel from ChannelFile
                if user_input:
                    in_channel.write(user_input)
                    in_channel.flush()
                    in_channel.channel.shutdown_write()
                while True:
                    # Check if timeout has been reached
                    if timeout is not None and (time.time() - start_time > timeout):
                        channel.close()
                        timeout_expired = True
                        break
                    # Grab the remaining data if process finished
                    if channel.exit_status_ready():
                        while channel.recv_ready():
                            std_out_chunks.append(channel.recv(4096))

                        while channel.recv_stderr_ready():
                            std_err_chunks.append(channel.recv_stderr(4096))
                        break
                    # Wait up to 0.5s for the channel to have stdout or stderr ready to read
                    read_ready, _, _ = select.select([channel], [], [], 0.5)
                    if read_ready:
                        # Read STDOUT
                        if channel.recv_ready():
                            std_out_chunks.append(channel.recv(4096))
                        # Read STDERR
                        if channel.recv_stderr_ready():
                            std_err_chunks.append(channel.recv_stderr(4096))
                    # Slight sleep to prevent busy waiting
                    time.sleep(0.1)

                # Get exit status if available
                exit_code = channel.recv_exit_status()
                # Combine the chunks of data
                std_out = b''.join(std_out_chunks)
                std_err = b''.join(std_err_chunks)
                # If execute command timeout expires, return the data as part of the exception
                if timeout_expired:
                    raise SSHTimeoutExpired('Timeout Reached.', std_out, std_err, exit_code)
            except SSHException as err:
                self._connected = False
                raise SSHManagerError(f'SSH connection prematurely terminated: {err}') from err
        return (std_out, std_err, exit_code)

    def create_remote_dir(self, remote_dir: str, fresh: bool = False) -> None:
        """Create a directory on the remote host.

        Args:
            remote_dir: Location of the desired directory on the remote host.
            fresh: If True, remote_dir will be deleted (if it exists) before being created.

        Raises:
            SSHManagerError: Unexpected problem with the connection or remote_dir exists and fresh
                is false.
        """
        self.connect()
        if self._connected:
            try:
                if self.remote_dir_exists(remote_dir):  # Check if the directory exists
                    if fresh:  # Overwrite it if desired
                        self.delete_remote_dir(remote_dir)
                    else:
                        raise SSHManagerError(f'Remote directory \'{remote_dir}\' already exists.')
                mkdir_cmd = ''  # Command used to create the remote directory based on the OS
                if self._check_remote_os() == 'Unix':
                    mkdir_cmd = f'mkdir -p {remote_dir}'
                else:  # Windows
                    remote_dir = remote_dir.replace('/', '\\\\')
                    mkdir_cmd = f'mkdir {remote_dir}'
                self.execute_command(mkdir_cmd)
            except SSHException as err:
                self._connected = False
                raise SSHManagerError(f'SSH connection prematurely terminated: {err}') from err

    def delete_remote_dir(self, remote_dir: str, ignore_missing: bool = False) -> None:
        """Delete a directory on the remote host.

        This will delete all files and subdirectories within the provided directory.

        Args:
            remote_dir: Location of the directory on the remote host.
            ignore_missing: Optional; Do not raise an Exception if remote_dir is already missing.

        Raises:
            SSHManagerError: SSH connection prematurely terminated or remote_dir is missing.
        """
        self.connect()
        if self._connected:
            try:
                if not self.remote_dir_exists(remote_dir):  # Check if the directory exists
                    if not ignore_missing:
                        raise SSHManagerError(f"Remote directory '{remote_dir}' does not exist.")
                else:
                    delete_cmd = ''  # Command to delete the remote directory based on the OS
                    if self._check_remote_os() == 'Unix':
                        delete_cmd = f'rm -rf {remote_dir}'
                    else:  # Windows
                        delete_cmd = f'rmdir /s /q "{remote_dir}"'
                    self.execute_command(delete_cmd)
            except SSHException as err:
                self._connected = False
                raise SSHManagerError(f'SSH connection prematurely terminated: {err}') from err

    def delete_remote_file(self, remote_file: str, ignore_missing: bool = False) -> None:
        """Delete a file on the remote host.

        Args:
            remote_dir: Location of the file on the remote host.
            ignore_missing: Optional; Do not raise an Exception if remote_file is already missing.

        Raises:
            SSHManagerError: SSH connection prematurely terminated or remote_file does not exist.
        """
        self.connect()
        if self._connected:
            try:
                if not self.remote_file_exists(remote_file):  # Check if the file exists
                    if not ignore_missing:
                        raise SSHManagerError(f'Remote file \'{remote_file}\' does not exist.')
                else:
                    delete_cmd = ''  # Command to delete the remote directory based on the OS
                    if self._check_remote_os() == 'Unix':
                        delete_cmd = f'rm {remote_file}'
                    else:  # Windows
                        delete_cmd = f'del "{remote_file}"'
                    self.execute_command(delete_cmd)
            except SSHException as err:
                self._connected = False
                raise SSHManagerError(f'SSH connection prematurely terminated: {err}') from err

    def join_remote_path(self, remote_dir: str, remote_parts: List[str]) -> str:
        """Join path components using the remote OS path separator.

        This method serves to gently replicate os.path.join()'s behavior depending on the
        OS of the remote host.

        Example usage (assuming the remote OS implicitly matches the remote_dir implication):
            join_remote_path('C:\\Temp', ['dir', 'file.txt']) --> 'C:\\Temp\\dir\\file.txt'
            join_remote_path('/tmp', ['dir','file.txt'])      --> '/tmp/dir/file.txt'
            join_remote_path('', ['dir', 'file.txt'])  # Win  --> 'dir\\file.txt'
            join_remote_path('', ['dir','file.txt'])   # Unix --> 'dir/file.txt'

        Args:
            remote_dir: Base remote directory (which should probably be an absolute path) as a
                string.  E.g., 'C:\\Temp', '/tmp/test_dir', './', ''.
            remote_parts: Non-empty list of additional path components to join to remote_dir, as
                strings.  E.g., ['dir1', 'file1.txt'], ['file2.txt'].

        Returns:
            Joined remote path as a string.  The results should effectively be the same as this
            statement executed on the remote OS:
                os.path.join(remote_dir, os.sep.join(remote_parts))

        Raises:
            OSError: If remote_parts contains an absolute path for the remote OS.
            RuntimeError: Failed to identify the remote OS.
            SSHManagerError: SSH connection prematurely terminated or unable to connect.
            TypeError: Bad data type.
            ValueError: Empty list, empty string.
        """
        # LOCAL VARIABLES
        working_path = None  # Variable to concatenate remote_parts entries to a base Path object
        remote_os = None     # Remote OS as reported by self._check_remote_os()
        path_class = None    # The pathlib Path class to use, based on the remote_os

        # INPUT VALIDATION
        validate_string(remote_dir, 'remote_dir', can_be_empty=True)
        validate_list(remote_parts, 'remote_parts', can_be_empty=False)
        for remote_part in remote_parts:
            validate_string(remote_part, 'remote_parts entry', can_be_empty=True)

        # SETUP
        self.connect()
        if self._connected:
            # DETERMINE REMOTE OS
            try:
                remote_os = self._check_remote_os()
            except SSHException as err:
                self._connected = False
                raise SSHManagerError(f'SSH connection prematurely terminated: {err}') from err
            if 'Unix' == remote_os:
                path_class = PurePosixPath
            elif 'Windows' == remote_os:
                path_class = PureWindowsPath
            else:
                raise RuntimeError(f'Unable to identify the remote OS for host {self._host}')
            # CREATE BASE PATH OBJECT
            working_path = path_class(remote_dir)
            # JOIN IT
            for remote_part in remote_parts:
                if path_class(remote_part).is_absolute():
                    raise OSError(f'Absolute path detected, for the remote OS of {remote_os}, '
                                  f'on remote host {self._host}, in remote_parts: {remote_part}')
                working_path = working_path / remote_part
        else:
            raise SSHManagerError(f'Not connected to host {self._host}')

        # DONE
        return str(working_path)

    def list_remote_dir(self, remote_dir: str) -> List[str]:
        """List the contents of a directory on the remote host.

        Args:
            remote_dir: Location of the directory on the remote host.

        Returns:
            A list of strings representing the contents of the remote directory.

        Raises:
            SSHManagerError: SSH connection prematurely terminated or remote_dir does not exist.
        """
        dir_contents = []  # Store the list of the directory contents
        self.connect()
        if self._connected:
            try:
                with self.client.open_sftp() as sftp:
                    if self.remote_dir_exists(remote_dir):  # Check if the directory exists
                        dir_contents = sftp.listdir(remote_dir)
                    else:
                        raise SSHManagerError(f'Remote directory \'{remote_dir}\' does not exist.')
            except SSHException as err:
                self._connected = False
                raise SSHManagerError(f'SSH connection prematurely terminated: {err}') from err
        return dir_contents

    def remote_dir_exists(self, remote_dir: str) -> bool:
        """Check if a directory exists on the remote host.

        Args:
            remote_dir: Location of the directory on the remote host.

        Returns:
            A bool indicating true/false if the directory exists.

        Raises:
            SSHManagerError: SSH connection prematurely terminated.
        """
        result = False  # Store the state of the check
        self.connect()
        if self._connected:
            try:
                check_cmd = ''  # Command to check if the remote directory exists based on the OS
                if self._check_remote_os() == 'Unix':
                    check_cmd = f'[ -d "{remote_dir}" ]'  # 0 for exists, 1 for missing
                else:  # Windows
                    check_cmd = f'if exist "{remote_dir}" (exit 0) else (exit 1)'
                _, _, stderr = self.client.exec_command(check_cmd)  # Store the command results
                exit_code = stderr.channel.recv_exit_status()  # Receive the command exit code
                result = exit_code == 0
            except SSHException as err:
                self._connected = False
                raise SSHManagerError(f'SSH connection prematurely terminated: {err}') from err
        return result

    def remote_file_exists(self, remote_file: str) -> bool:
        """Check if a file exists on the remote host.

        Args:
            remote_file: Location of the file on the remote host.

        Returns:
            A bool indicating true/false if the file exists.

        Raises:
            SSHManagerError: SSH connection prematurely terminated.
        """
        result = False  # Store the state of the check
        self.connect()
        if self._connected:
            try:
                check_cmd = ''  # Command to check if the remote directory exists based on the OS
                if self._check_remote_os() == 'Unix':
                    check_cmd = f'[ -f "{remote_file}" ]'
                else:  # Windows
                    check_cmd = f'if exist "{remote_file}" (exit 0) else (exit 1)'
                _, _, stderr = self.client.exec_command(check_cmd)  # Store the command results
                exit_code = stderr.channel.recv_exit_status()  # Receive the command exit code
                result = exit_code == 0
            except SSHException as err:
                self._connected = False
                raise SSHManagerError(f'SSH connection prematurely terminated: {err}') from err
        return result

    def remote_path_basename(self, remote_path: str) -> str:
        """Replicates the behavior of os.path.basename() for remote hosts.

        Args:
            remote_path: Remote path of item.

        Returns:
            A string containing the base name of the remote path.

        Raises:
            SSHManagerError: SSH connection prematurely terminated.
        """
        basename = ''  # Store the basename result
        self.connect()
        if self._connected:
            try:
                # Grab the appropriate OS path separator
                separator = '/' if self._check_remote_os() == 'Unix' else '\\'
                remote_parts = remote_path.split(separator)  # Split the remote path by separator
                if remote_parts:
                    basename = remote_parts[-1]
            except SSHException as err:
                self._connected = False
                raise SSHManagerError(f'SSH connection prematurely terminated: {err}') from err
        return basename

    def transfer_dir_to_local(self, remote_dir: str, local_path: str, force: bool = False) -> None:
        """Transfer a directory from the remote host to the local host.

        Source and destination locations can both be relative or absolute.

        Args:
            remote_dir: Location of the directory on the remote host.
            local_path: Location to copy this directory to on the local host.
            force: True/false whether to overwrite the local directory if it already exists.

        Raises:
            FileExistsError: local_path already exists.
            SSHManagerError: SSH connection prematurely terminated or remote_dir does not exist.
        """
        self.connect()
        if self._connected:
            try:
                if not self.remote_dir_exists(remote_dir):  # Check if the remote directory exists
                    raise SSHManagerError(f'Remote directory \'{remote_dir}\' does not exist.')
                # Create a reference to the local directory
                local_dir = os.path.join(local_path, self.remote_path_basename(remote_dir))
                if os.path.exists(local_dir):  # Check if the local directory exists
                    if force:  # Overwrite it if desired
                        shutil.rmtree(local_dir)
                        os.mkdir(local_dir)
                    else:
                        raise FileExistsError(f'Local directory \'{local_dir}\' already exists.')
                with self.client.open_sftp() as sftp:
                    self._transfer_dir_to_local_recursive(sftp, remote_dir, local_path)
            except SSHException as err:
                self._connected = False
                raise SSHManagerError(f'SSH connection prematurely terminated: {err}') from err

    def transfer_dir_to_remote(self, local_dir: str, remote_path: str, force: bool = False) -> None:
        """Transfer a directory from the local host to the remote host.

        Source and destination locations can both be relative or absolute.

        Args:
            local_dir: Location of the directory on the local host.
            remote_path: Location to copy this directory to on the remote host.
            force: True/false whether to overwrite the remote directory if it already exists.

        Raises:
            FileNotFoundError: local_dir does not exist.
            SSHManagerError: SSH connection prematurely terminated or remote_dir already exists.
        """
        self.connect()
        if self._connected:
            try:
                if not os.path.exists(local_dir):  # Check if the local directory exists
                    raise FileNotFoundError(f'Local directory \'{local_dir}\' does not exist.')
                # Create a reference to the remote directory
                remote_dir = self.join_remote_path(remote_path, [os.path.basename(local_dir)])
                if self.remote_dir_exists(remote_dir):  # Check if the remote directory exists
                    if force:  # Overwrite it if desired
                        self.create_remote_dir(remote_dir, force)
                    else:
                        raise SSHManagerError(f'Remote directory \'{remote_dir}\' already exists.')
                with self.client.open_sftp() as sftp:
                    self._transfer_dir_to_remote_recursive(sftp, local_dir, remote_path)
            except SSHException as err:
                self._connected = False
                raise SSHManagerError(f'SSH connection prematurely terminated: {err}') from err

    def transfer_file_to_local(self, remote_file: str, local_dir: str, force: bool = False) -> None:
        """Transfer a file from the remote host to the local host.

        Source and destination locations can be relative or absolute.

        Args:
            remote_file: Location of the file on the remote host.
            local_dir: Location of the directory to copy this file to on the local host.
            force: Optional; True/false whether to overwrite the local file if it already exists.

        Raises:
            FileExistsError: remote_file already exists in local_dir and force is False.
            FileNotFoundError: If local_dir does not exist as a directory.
            SSHManagerError: SSH connection prematurely terminated or remote_file does not exist.
        """
        self.connect()
        if self._connected:
            # Validate local environment
            try:
                validate_directory(local_dir, 'local_dir', must_exist=True)
            except FileNotFoundError as err:
                raise FileNotFoundError(f'Unable to find the "local_dir": {local_dir}') from err

            # Transfer it
            try:
                # Validate remote environment
                if not self.remote_file_exists(remote_file):  # Check if the remote file exists
                    raise SSHManagerError(f'Remote file \'{remote_file}\' does not exist.')
                filename = self.remote_path_basename(remote_file)  # Grabbing the base filename
                local_file = os.path.join(local_dir, filename)  # Creating the local path
                if os.path.exists(local_file):  # Check if the local file exists
                    if force:  # Overwrite it if desired
                        os.remove(local_file)
                    else:
                        raise FileExistsError(f'Local file \'{local_file}\' already exists.')
                with self.client.open_sftp() as sftp:
                    sftp.get(remote_file, local_file)
            except SSHException as err:
                self._connected = False
                raise SSHManagerError(f'SSH connection prematurely terminated: {err}') from err

    def transfer_file_to_remote(self, local_file: str, remote_dir: str,
                                force: bool = False) -> None:
        """Transfer a file from the local host to the remote host.

        Source and destination locations can both be relative or absolute.

        Args:
            local_path: Location of the file on the local host.
            remote_dir: Location of the directory to copy this file to on the remote host.
            force: Optional; True/false whether to overwrite the remote file if it already exists.

        Raises:
            FileNotFoundError: local_file does not exist.
            SSHManagerError: Remote directory does not exist.
            SSHManagerError: SSH connection prematurely terminated or local_file exists in
                remote_dir and force is False.
        """
        self.connect()
        if self._connected:
            try:
                # Validate local file exists
                validate_file(local_file, 'local_file', must_exist=True)
            except FileNotFoundError as err:
                raise FileNotFoundError(f'Local file "{local_file}" does not exist.') from err
            try:
                filename = os.path.basename(local_file)  # Grabbing the base filename
                remote_file = self.join_remote_path(remote_dir, [filename])  # Creating remote path
                if not self.remote_dir_exists(remote_dir):  # Check if the remote directory exists
                    raise SSHManagerError(f'Remote directory "{remote_file}" does not exist.')
                if self.remote_file_exists(remote_file):  # Check if the remote file exists
                    if force:  # Overwrite it if desired
                        self.delete_remote_file(remote_file)
                    else:
                        raise SSHManagerError(f'Remote file "{remote_file}" already exists.')
                with self.client.open_sftp() as sftp:
                    sftp.put(local_file, remote_file)
            except SSHException as err:
                self._connected = False
                raise SSHManagerError(f'SSH connection prematurely terminated: {err}') from err

    # PRIVATE FUNCTIONS
    def _check_remote_os(self) -> str:
        """Check the OS type of the remote host.

        This method only checks once and stores the value.  If the connection is ever terminated,
        this method will reset the value.

        Returns:
            One of three results: Unix for *nix, Windows for Microsoft, and empty string if
            there's no current connection.
        """
        self.connect()
        if self._connected:
            if not self._os_type:
                std_out, std_err, exit_code = self.execute_command('uname')
                if std_err or 0 != exit_code:
                    self._os_type = 'Windows'
                elif std_out.lower().startswith(b'Windows'.lower()):
                    self._os_type = 'Windows'  # Windows + Cygwin
                else:
                    self._os_type = 'Unix'
        else:
            self._os_type = ''  # Unknown since it's not connected
        return self._os_type

    def _transfer_dir_to_local_recursive(self, sftp: SFTPClient, remote_dir: str,
                                         local_path: str) -> None:
        """Recursively transferring a directory from the remote host to the local host.

        Source and destination locations can both be relative or absolute.

        Args:
            sftp: Currently opened sftp connection for this operation.
            remote_dir: Location of the directory on the remote host.
            local_path: Location to copy this directory to on the local host.
        """
        for item in self.list_remote_dir(remote_dir):
            remote_item = self.join_remote_path(remote_dir, [item])  # Create remote path
            local_item = os.path.join(local_path, item)  # Create local path to the item
            if self.remote_file_exists(remote_item):  # Check if the item is a file
                sftp.get(remote_item, local_item)
            elif self.remote_dir_exists(remote_item):  # Check if the item is a directory
                os.mkdir(local_item)
                self._transfer_dir_to_local_recursive(sftp, remote_item, local_item)

    def _transfer_dir_to_remote_recursive(self, sftp: SFTPClient, local_dir: str,
                                          remote_path: str) -> None:
        """Recursively transferring a directory from the local host to the remote host.

        Source and destination locations can both be relative or absolute.

        Args:
            sftp: Currently opened sftp connection for this operation.
            local_dir: Location of the directory on the local host.
            remote_path: Location to copy this directory to on the remote host.
        """
        for item in os.listdir(local_dir):
            local_item = os.path.join(local_dir, item)  # Create local path to the item
            remote_item = self.join_remote_path(remote_path, [item])  # Create remote path
            if os.path.isfile(local_item):  # Check if the item is a file
                sftp.put(local_item, remote_item)
            elif os.path.isdir(local_item):  # Check if the item is a directory
                self.create_remote_dir(remote_item)
                self._transfer_dir_to_remote_recursive(sftp, local_item, remote_item)
