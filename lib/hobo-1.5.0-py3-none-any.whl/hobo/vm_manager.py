"""Defines the VMManager Class.

Import VMManager for more details and usage instructions.

    Typical usage example:

    from hobo.vm_manager import VMManager, VMManagerError

    # Creation
    vmrun_path = 'C:\\Program Files (x86)\\VMware\\VMware Player\\vmrun.exe'
    vm_path = 'C:\\Users\\public\\Documents\\Virtual Machines\\Example VM\\vm.vmx'
    vm_manager = VMManager(vmrun_path, vm_path)

    # Startup
    try:
        vm_manager.start_vm()
    except VMManagerError as err:
        print(err)

    # Shutdown
    try:
        vm_manager.shutdown_vm()
    except VMManagerError as err:
        print(err)

NOTE: VMWare Workstation or Player are required to be installed on the local host for this class.
"""

import os
import subprocess
import time
from typing import Final


START_TIMEOUT: Final[int] = 300  # Default maximum time to wait for VM to start in seconds
SHUTDOWN_TIMEOUT: Final[int] = 30  # Default maximum time to wait for VM to shutdown in seconds
POLL_RATE: Final[int] = 1  # Default time between checking the VM state in seconds


class VMManagerError(Exception):
    """Custom exception for VMManager failures."""


class VMManager:
    """Virtual Machine Manager Class.

    Defines functionality for managing starting/stopping a virtual machine.

    Available features:
        1. Start the virtual machine
        2. Shutdown the virtual machine
    """

    # CONSTRUCTOR
    def __init__(self, vmrun_path: str, vm_path: str) -> None:
        """VMManager ctor.

        vmrun_path and vm_path can be absolute or relative.

        Args:
            vmrun_path: Local path to the vmrun.exe executable.
            vm_path: Local path to the .vmx file to use.
        """
        self._vmrun_path = vmrun_path  # Local path to the vmrun.exe executable
        self._vm_path = vm_path        # Local path to the .vmx file to use

    # PUBLIC FUNCTIONS
    def start_vm(self, timeout: int = START_TIMEOUT, poll_rate: int = POLL_RATE) -> None:
        """Start the virtual machine.

        Args:
            timeout: Optional; Maximum time to wait for this operation to succeed in seconds.
            poll_rate: Optional; Time between checking the VM state in seconds.

        Raises:
            VMManagerError for the following errors:
                - vmrun file not found
                - vm file not found
                - unable to start vm
        """
        success = False  # Store the result of the operation
        # Check if the VM files exist
        self._check_vm_files()
        # Check if the VM is already running
        if not self._check_vm_state():
            # Create the VM start command 'vmrun.exe start vmfile.vmx'
            command = [self._vmrun_path, 'start', self._vm_path]
            # Use subprocess.Popen for non-blocking execution
            with subprocess.Popen(command):
                start_time = time.time()
                while time.time() - start_time < timeout:
                    if self._check_vm_state():
                        success = True
                        break
                    time.sleep(poll_rate)
            if not success:
                # Unable to start VM, raise exception
                raise VMManagerError('Failed to start the virtual machine.')

    def shutdown_vm(self, timeout: int = SHUTDOWN_TIMEOUT, poll_rate: int = POLL_RATE) -> None:
        """Shutdown the virtual machine.

        Args:
            timeout: Optional; Maximum time to wait for this operation to succeed in seconds.
            poll_rate: Optional; Time between checking the VM state in seconds.

        Raises:
            VMManagerError for the following errors:
                - vmrun file not found
                - vm file not found
                - unable to shutdown vm
        """
        success = False  # Store the result of the operation
        # Check if the VM files exist
        self._check_vm_files()
        # Check if the VM is already shutdown
        if self._check_vm_state():
            # Create the VM stop command 'vmrun.exe stop vmfile.vmx'
            command = [self._vmrun_path, 'stop', self._vm_path]
            # Use subprocess.Popen for non-blocking execution
            with subprocess.Popen(command):
                start_time = time.time()
                while time.time() - start_time < timeout:
                    if not self._check_vm_state():
                        success = True
                        break
                    time.sleep(poll_rate)
            if not success:
                # Unable to start VM, raise exception
                raise VMManagerError('Failed to shutdown the virtual machine.')

    # PRIVATE FUNCTIONS
    def _check_vm_files(self) -> None:
        """Check if the necessary VM files exist.

        Raises:
            VMManagerError for the following errors:
                - vmrun file not found
                - vm file not found
        """
        # Check if the vmrun file exists
        if not os.path.exists(self._vmrun_path):
            raise VMManagerError('vmrun file not found.')
        # Check if the VM file exists
        if not os.path.exists(self._vm_path):
            raise VMManagerError('VM file not found.')

    def _check_vm_state(self) -> bool:
        """Check the running state of the virtual machine.

        Returns:
            A bool indicating whether the VM is on(true) or off(false).
        """
        state = False  # Store the result of the virtual machine state
        vm_ip = self._get_vm_ip()  # Get the current virtual machine IP address
        if vm_ip is not None:
            state = True
        return state

    def _get_vm_ip(self) -> str:
        """Get the IP address of the virtual machine.

        Returns:
            A string containing the virtual machine IP address.
        """
        ip_addr = None  # Store the result of the virtual machine IP address check
        # Create the VM get IP address command 'vmrun.exe getGuestIPAddress vmfile.vmx'
        command = [self._vmrun_path, 'getGuestIPAddress', self._vm_path]
        try:
            # Store the result of the command
            result = subprocess.run(command, text=True, capture_output=True, check=True)
            ip_addr = result.stdout.strip()
        except subprocess.CalledProcessError:
            pass
        return ip_addr
