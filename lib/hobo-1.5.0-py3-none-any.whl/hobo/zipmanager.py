"""Defines the ZipManager class.

The ZipManager class validates, reads, and expands ZIP files using Python's zipfile module.

    Typical usage example:

    zip_mgr_obj = ZipManager('my_archive.zip')
    extracted_file = zip_mgr_obj.extract_archive_member('my_file.txt', './put/it/here')
"""

# Standard Imports
from zipfile import BadZipFile, ZipFile
# Local Imports
from hobo.disk_operations import validate_directory, validate_file
from hobo.validation import validate_string, validate_type


class ZipManager:
    """Validate, read, and expand ZIP files.

    Validates and extracts 'member's from ZIP files using Python's zipfile module.
    Additional functionality (e.g., write, full-expansion) was not immediately needed but could
    be added.
    """

    def __init__(self, archive: str) -> None:
        """ZipManager class ctor.

        Archive validation is performed once when the first method is called.

        Args:
            archive: Filename, relative or absolute, to a valid zip archive as a string.
        """
        self._archive = archive  # ZIP filename
        self._validated = False  # Controls archive validation

    def extract_archive_member(self, member: str, dst_dir: str) -> str:
        """Extract member from archive into dst_dir.

        Extract a specific file from archive into a destination directory.  If member exists in
        dst_dir, it will be overwritten.

        Args:
            member: Name of a file inside archive.
            dst_dir: A directory to extract member into.

        Returns:
            Filename for the newly extracted member.

        Raises:
            FileNotFoundError: self._archive is not found.
            FileNotFoundError: dst_dir is not found.
            KeyError: member was not located in self._archive.
            OSError: dst_dir is not a directory.
            OSError: self._archive is not a file.
            RuntimeError: Unanticipated exception raised by ZipFile object.
            TypeError: Invalid data type.
            ValueError: empty argument.
        """
        # LOCAL VARIABLES
        extracted_file = ''  # Filename for the newly extracted member

        # INPUT VALIDATION
        # self._archive
        self.validate_archive()
        # member
        validate_string(validate_this=member, param_name='member', can_be_empty=False)
        # dst_dir
        validate_directory(validate_dir=dst_dir, param_name='dst_dir', must_exist=True)

        # EXTRACT IT
        try:
            with ZipFile(self._archive) as zip_obj:
                extracted_file = zip_obj.extract(member=member, path=dst_dir)
        except KeyError as err:
            raise KeyError(f'Unable to locate {member} in {self._archive}') from err
        except Exception as err:
            raise RuntimeError('ZipFile raised an Exception (after being validated) while '
                               f'extracting {member} from {self._archive} into '
                               f'{dst_dir}: {str(err)}') from err

        # DONE
        return extracted_file

    def validate_archive(self) -> None:
        """Validates archive.

        Validates the archive provided in the ctor just once.

        Raises:
            FileNotFoundError: self._archive is not found.
            OSError: self._archive is not a file.
            TypeError: Invalid data type.
            ValueError: self._archive is empty.
        """
        # ATTRIBUTE VALIDATION
        validate_type(self._validated, 'internal attribute _validated', bool)
        if not self._validated:
            # Exists as a file
            validate_file(filename=self._archive, param_name='archive', must_exist=True)
            # Is a valid ZIP file
            self._validate_archive()
            # Mark it as valid
            self._validated = True

    def _validate_archive(self) -> None:
        """Validate self._archive as an actual ZIP file.

        No input validation is performed.

        Raises:
            FileNotFoundError: self._archive is not found.
            RuntimeError: self._archive is not a valid ZIP file or it contains a bad file.
        """
        # LOCAL VARIABLES
        bad_member = None  # ZipFile.testzip() results
        # NOTE: ZipFile.testzip() returns the name of the first bad file, or else returns None.

        # VALIDATE IT
        # Valid ZIP?
        try:
            with ZipFile(self._archive) as zip_obj:
                bad_member = zip_obj.testzip()
        except FileNotFoundError as err:
            raise FileNotFoundError(f'ZipFile ctor was unable to find {self._archive}: '
                                    f'{str(err)}') from err
        except ValueError as err:
            # Top cause: Calling testzip() on an object that's been close()ed... so this should
            # never happen... unless the input wasn't validated by the caller.
            raise RuntimeError(f'Error with {self._archive}: {str(err)}') from err
        except (BadZipFile, RuntimeError) as err:
            raise RuntimeError(f'{self._archive} is not a valid zip file: {str(err)}') from err
        # Bad member in the ZIP?
        if bad_member:
            raise RuntimeError(f'ZipFile identified {bad_member} as "bad" '
                               f'in {self._archive}')
