"""Tedious Start (TEST) module containing package-wide global variables.

    Typical usage example:

    1. from tediousstart.config import TEST_VERBOSE_OVERRIDE
    2. print(TEST_VERBOSE_OVERRIDE)

"""
# Standard Imports
from typing import Final
# Third Party Imports
# Local Imports

# Holds the environment variable to override verbosity to Verbosity.ALL
TEST_VERBOSE_OVERRIDE: Final[str] = 'TEDIOUS_START_VERBOSE_OVERRIDE'
